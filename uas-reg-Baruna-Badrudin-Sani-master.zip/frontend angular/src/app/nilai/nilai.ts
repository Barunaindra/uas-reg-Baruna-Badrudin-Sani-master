export class Nilai {
  title: string;
  nama: string;
  nilai: string;
  matkul: string;
  updated_at: string;
}
